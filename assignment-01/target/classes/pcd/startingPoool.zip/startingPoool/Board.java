package pcd.startingPoool;

import java.util.List;

import static pcd.startingPoool.Ball.resolveCollision;

public class Board {

    private List<Ball> balls;
    private Ball playerBall;
    private Ball botBall;
    private Boundary bounds;
    
    public Board(){} 
    
    public void init(BoardConf conf) {
    	balls = conf.getSmallBalls();    	
    	playerBall = conf.getPlayerBall();
        botBall = conf.getBotBall();
    	bounds = conf.getBoardBoundary();
    }
    
    public void updateState(long dt) {

    	playerBall.updateState(dt, this);
        botBall.updateState(dt, this);
    	
    	for (var b: balls) {
    		b.updateState(dt, this);
    	}       	
    	
    	for (int i = 0; i < balls.size() - 1; i++) {
            for (int j = i + 1; j < balls.size(); j++) {
                //si verifica se le palline collidono allora sono allontanate secondo la normale
                resolveCollision(balls.get(i), balls.get(j));
            }
        }
    	for (var b: balls) {
    		resolveCollision(playerBall, b);
    	}
        for (var b: balls) {
            resolveCollision(botBall, b);
        }

    }
    
    public List<Ball> getBalls(){
    	return balls;
    }
    
    public Ball getPlayerBall() {
    	return playerBall;
    }

    public Ball getBotBall(){ return botBall; }
    
    public Boundary getBounds(){
        return bounds;
    }

    public void updateHumanBall(V2d velocity){ playerBall.kick(velocity); }
}
