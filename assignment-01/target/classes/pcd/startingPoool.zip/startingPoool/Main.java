package pcd.startingPoool;

import pcd.startingPoool.view.View;
import pcd.startingPoool.view.ViewModel;
import pcd.startingPoool.controller.ActiveController;

public class Main {

    public static void main(String[] argv) {

        // istanziazione del model, ovvero della board del gioco (palline)
        var conf = new StandardConf();
        var board = new Board();
        board.init(conf);

        //istanziazione del controller, che è un componente attivo che modifica il model a seguito
        //dell'input dell'utente
        var controller = new ActiveController(board);

        var viewModel = new ViewModel();
        var view = new View(viewModel, 900, 600, controller);
        //model.addObserver(view);


        controller.start();

        view.render();



    }

}
